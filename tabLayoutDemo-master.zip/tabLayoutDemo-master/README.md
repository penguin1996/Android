## tabLayoutDemo 
利用tabLayot+viewpager+fragment去仿网易新闻去实现顶部导航条和底部导航条    use tayout , viewPager and fragment to solve Top navigation bar and bottom navigation bar

##演示效果图 如下:
![image](https://github.com/willBars/tabLayoutDemo/raw/master/screenshort/screenshotone.png)
![image](https://github.com/willBars/tabLayoutDemo/raw/master/screenshort/screenshotthree.png)
![image](https://github.com/willBars/tabLayoutDemo/raw/master/screenshort/screenshottwo.png)
