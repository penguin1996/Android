# DatabindingDemo
这只是一个MVVM模式下，RecycerView数据加载的演示案例

![](https://raw.githubusercontent.com/Ccapton/DatabindingDemo/master/demo.gif)
