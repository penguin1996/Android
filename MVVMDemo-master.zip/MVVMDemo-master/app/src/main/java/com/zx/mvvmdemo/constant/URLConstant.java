package com.zx.mvvmdemo.constant;

/**
 * 作者： 周旭 on 2017年10月17日 0017.
 * 邮箱：374952705@qq.com
 * 博客：http://www.jianshu.com/u/56db5d78044d
 */

public class URLConstant {
    public static final String URL_NEWS = "https://news-at.zhihu.com/api/4/themes";
    public static final String URL_BASE = "https://news-at.zhihu.com/";
    public static final String URL_PATH = "api/4/themes";
}
