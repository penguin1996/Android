package com.zx.mvvmdemo.view;

import com.zx.mvvmdemo.base.IBaseView;

/**
 * 作者： 周旭 on 2017年10月19日 0019.
 * 邮箱：374952705@qq.com
 * 博客：http://www.jianshu.com/u/56db5d78044d
 */

public interface INewsView extends IBaseView {

    /**
     * 实际项目中可能还有其他的接口，此处写出来便于拓展
     */
}
