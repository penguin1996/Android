package com.zx.mvvmdemo.constant;

/**
 * 作者： 周旭 on 2017年10月19日 0019.
 * 邮箱：374952705@qq.com
 * 博客：http://www.jianshu.com/u/56db5d78044d
 */

public class MainConstant {

    public class LoadData {
        public static final int FIRST_LOAD = 0; //首次加载
        public static final int REFRESH = 1; //下拉刷新
        public static final int LOAD_MORE = 2; //上拉加载更多
    }
}
