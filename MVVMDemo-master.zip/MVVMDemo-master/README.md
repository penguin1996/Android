# MVVMDemo
Android MVVM模式的RecyclerView Demo

整体架构MVVM，网络请求用的是retrofit2+rxjava2,图片加载用的Glide，列表用的xRecyclerView库

`效果图`

![新闻列表](https://github.com/zhouxu88/MVVMDemo/blob/master/screenshots/demo.gif)

