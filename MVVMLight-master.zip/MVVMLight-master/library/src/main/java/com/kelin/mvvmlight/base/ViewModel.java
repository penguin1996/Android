package com.kelin.mvvmlight.base;

import android.view.View;

/**
 * Created by kelin on 16-3-15.
 */
public interface ViewModel {

}
